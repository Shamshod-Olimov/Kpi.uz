

<?php $__env->startSection('content'); ?>

    <br>
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success" style="width: 40%; height: 50px" id="alert">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>

    <?php $no = 1 ?>

    <table class="table text-left">
        <tr>
            <th>№</th>
            <th style="min-width:200px"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('leadership'));?>Rahbariyat</th>
            <th style="min-width:200px"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('department'));?>Boshqarma</th>
            <th style="min-width:200px"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('section'));?>Bo'lim</th>
            <th style="min-width:200px"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('speciality'));?>Lavozim</th>
            <th style="min-width:200px"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('worker'));?>Xodimlar</th>
            <th style="min-width:200px" class="table text-center"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('done'));?>O'z vaqtida bajarilgan<br>topshiriqar ulushi<br>(foizda)</th>
            <th style="min-width:200px" class="table text-center"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('executive_discipline'));?>Ijro intizomi<br>talablariga rioya<br>etilganligi uchun ballar<br>(15-60 ballgacha)</th>
            <th style="min-width:200px" class="table text-center"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('initiative'));?>Tashabbuskorlik<br>uchun ballar<br>(15 ballgacha)</th>
            <th style="min-width:200px" class="table text-center"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('extra'));?>Yuqori turuvchi rahbar<br>tomonidan belgilangan<br>qo'shimcha ballar<br>(25 ballgacha)</th>
            <th style="min-width:200px" class="table text-center"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('total'));?>Umumiy ball</th>
            <th style="min-width:200px" class="table text-center"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('kpi_per'));?>Ustama foiz miqdori</th>
            <th style="min-width:140px"></th>
        </tr>
        <?php if($informations->count()): ?>
        <?php $__currentLoopData = $informations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $information): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($information->leadership); ?></td>
            <td><?php echo e($information->department); ?></td>
            <td><?php echo e($information->section); ?></td>
            <td><?php echo e($information->speciality); ?></td>
            <td><?php echo e($information->worker); ?></td>
            <td><?php echo e($information->done); ?></td>
            <td><?php echo e($information->executive_discipline); ?></td>
            <td><?php echo e($information->initiative); ?></td>
            <td><?php echo e($information->extra); ?></td>
            <td><?php echo e($information->total); ?></td>
            <td><?php echo e($information->kpi_per); ?></td>
            <td class="text-right pr-5">
                <a href="calculator/delete/<?php echo e($information->id); ?>" class="btn btn-danger">O'chirish</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </table>
    <?php echo e($informations->links()); ?>

    <a href="export" class="btn btn-success">Excel fayl</a> <br>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    const message = document.querySelector('#alert')
    setTimeout(() => {
        message.style.display = 'none'
    }, 2000);
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\A_Project\Kpi.uz\resources\views/information/index.blade.php ENDPATH**/ ?>