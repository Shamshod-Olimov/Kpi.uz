

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <a class="btn btn-success" href="section/add" style="width: 200px"> Yangi kiritish </a>
            </div>
            <div class="pull-right mr-5">
                <h2>Bo'limlar</h2>
            </div>
        </div>
    </div>
    <br>
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success" style="width: 40%; height: 50px" id="alert">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <?php $no = 1 ?>

    <table class="table">
        <tr>
            <th>№</th>
            <th>Boshqarma</th>
            <th>Nomi</th>
        </tr>
        <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($no++); ?></td>
                <td>
                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($section->department_id == $department->id): ?> <?php echo e($department->name); ?> <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td><?php echo e($section->name); ?></td>
                <td class="text-right pr-5">
                    <a href="section/edit/<?php echo e($section->id); ?>" class="btn btn-primary">Tahrirlash</a>
                    <a href="section/delete/<?php echo e($section->id); ?>" class="btn btn-danger">O'chirish</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    const message = document.querySelector('#alert')
    setTimeout(() => {
        message.style.display = 'none'
    }, 2000);
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\A_Project\Kpi.uz\resources\views/section/index.blade.php ENDPATH**/ ?>