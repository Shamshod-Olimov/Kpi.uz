
<?php $__env->startSection('content'); ?>

<div><a class="btn btn-primary" style="width: 150px" href="/worker"> Orqaga </a></div>
    <div class="card card-primary col-md-6" style="margin-left: 15vw; margin-top: -6vh; height: 73vh">
        <div class="card-header" style="width: 102.5%; margin-left: -7.5px">
            <h3 class="card-title">Update worker</h3>
        </div>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> Kiritish bilan bog'liq xatolik. <br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <!-- /.card-header -->
        <!-- form start -->
        <?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form action="/worker/edit/<?php echo e($worker->id); ?>" method="POST" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <div class="card-body">
                <div class="form-group row">
                    <label for="name" class="col-4"> Ism </label>
                    <input type="text" class="col-8 form-control" id="name" name="name" value="<?php echo e($worker->name); ?>">
                </div>
                <div class="form-group row">
                    <label for="surname" class="col-4"> Familya </label>
                    <input type="text" class="col-8 form-control" id="surname" name="surname" value="<?php echo e($worker->surname); ?>">
                </div>
                <div class="form-group row">
                    <label for="speciality" class="col-4"> Lavozimi </label>
                    <select class="col-8 form-control" id="speciality" name="speciality" >
                        <option value="Yetakchi mutaxassis" <?php if('Yetakchi mutaxassis' == $worker->speciality): ?> selected <?php endif; ?>> Yetakchi mutaxassis </option>
                        <option value="Bosh mutaxassis" <?php if('Bosh mutaxassis' == $worker->speciality): ?> selected <?php endif; ?>> Bosh mutaxassis</option>
                        <option value="Bo'lim boshlig'i" <?php if("Bo'lim boshlig'i" == $worker->speciality): ?> selected <?php endif; ?>> Bo'lim boshlig'i </option>
                      </select>
                </div>
                <div class="form-group row">
                    <label for="section_id" class="col-4"> Bo'limi </label>
                    <select class="col-8 form-control" id="section_id" name="section_id" >
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($worker->section_id == $section->id): ?>
                                <option value="<?php echo e($section->id); ?>" selected>
                                    <?php echo e($section->name); ?>

                                </option>
                            <?php else: ?>
                                <option value="<?php echo e($section->id); ?>"> <?php echo e($section->name); ?> </option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group row">
                    <label for="status" class="col-4"> Statusi </label>
                    <select class="col-8 form-control" id="status" name="status" >
                        <option value="Aktiv" <?php if('Aktiv' == $worker->status): ?> selected <?php endif; ?>> Aktiv </option>
                        <option value="Tatilda" <?php if('Tatilda' == $worker->status): ?> selected <?php endif; ?>> Tatilda </option>
                      </select>
                </div>
            </div>
            <button type="submit" class="btn btn-primary" style="margin: 10px 10px 15px 20px"> Saqlash </button>
        </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\A_Project\Kpi.uz\resources\views/worker/edit.blade.php ENDPATH**/ ?>