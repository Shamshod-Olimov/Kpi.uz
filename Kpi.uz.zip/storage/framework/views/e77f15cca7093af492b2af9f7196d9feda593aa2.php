
<?php $__env->startSection('content'); ?>

<div><a class="btn btn-primary" style="width: 150px" href="/department"> Orqaga </a></div>
    <div class="card card-primary col-md-6" style="margin-left: 15vw; margin-top: -6vh; height: 73vh">
        <div class="card-header" style="width: 102.5%; margin-left: -7.5px">
            <h3 class="card-title"> Boshqarmani tahrirlash </h3>
        </div>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> Kiritish bilan bog'liq xatolik. <br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <!-- /.card-header -->
        <!-- form start -->
        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form action="/department/edit/<?php echo e($department->id); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="card-body">
                <div class="form-group row">
                    <label for="leadership_id" class="col-4"> Rahbariyat </label>
                    <select class="col-8 form-control" id="leadership_id" name="leadership_id" >
                        <?php $__currentLoopData = $leaderships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leadership): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($department->leadership_id == $leadership->id): ?>
                                <option value="<?php echo e($leadership->id); ?>" selected>
                                    <?php echo e($leadership->name); ?>

                                </option>
                            <?php else: ?>
                                <option value="<?php echo e($leadership->id); ?>"> <?php echo e($leadership->name); ?> </option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group row">
                    <label for="name" class="col-4"> Boshqrma nomi </label>
                    <input type="text" class="col-8 form-control" id="name" name="name" value="<?php echo e($department->name); ?>">
                </div>
            </div>
            <button type="submit" class="btn btn-primary" style="margin: 10px 10px 15px 20px"> Saqlash </button>
        </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\A_Project\Kpi.uz\resources\views/department/edit.blade.php ENDPATH**/ ?>