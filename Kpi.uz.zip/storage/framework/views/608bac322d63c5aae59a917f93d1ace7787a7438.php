

<?php $__env->startSection('content'); ?>

    <br>
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success" style="width: 40%; height: 50px" id="alert">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>

    <?php $no = 1 ?>

    <table class="table text-left">
        <tr>
            <th>№</th>
            <th>Rahbariyat</th>
            <th>Boshqarma</th>
            <th>Bo'lim</th>
            <th>Lavozim</th>
            <th>Xodimlar</th>
            <th style="min-width:200px" class="table text-center">O'z vaqtida bajarilgan<br>topshiriqar ulushi<br>(foizda)</th>
            <th style="min-width:200px" class="table text-center">Ijro intizomi<br>talablariga rioya<br>etilganligi uchun ballar<br>(15-60 ballgacha)</th>
            <th style="min-width:200px" class="table text-center">Tashabbuskorlik<br>uchun ballar<br>(15 ballgacha)</th>
            <th style="min-width:200px" class="table text-center">Yuqori turuvchi rahbar<br>tomonidan belgilangan<br>qo'shimcha ballar<br>(25 ballgacha)</th>
        </tr>

        <?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


        <?php
            $status = $worker->status;
            $worker_name = "$worker->name" . " " . "$worker->surname";
            $name = 'Blabla';
        ?>

        <?php $__currentLoopData = $kpis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kpi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($kpi->worker == $worker_name): ?>
                <div style="display: none">
                    <?php echo e($name = $kpi->worker); ?>

                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if($status == 'Aktiv' && $worker_name != $name): ?>
            <form method="POST" action="/calculator">
            <?php echo csrf_field(); ?>
            <tr>
                <td><?php echo e($no++); ?></td>
                <td>
                <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $leaderships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leadership): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($department->leadership_id == $leadership->id && $section->department_id == $department->id && $worker->section_id == $section->id ): ?>
                        <input
                            style="border:none"
                            type="text"
                            id="leadership"
                            name="leadership"
                            value="<?php echo e($leadership->name); ?>"
                            placeholder="<?php echo e($leadership->name); ?>"
                            readonly>
                    <?php else: ?>

                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>

                <td>
                <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($section->department_id == $department->id && $worker->section_id == $section->id): ?>
                        <input
                            style="border:none"
                            type="text"
                            id="department"
                            name="department"
                            value="<?php echo e($department->name); ?>"
                            placeholder="<?php echo e($department->name); ?>"
                            readonly>
                    <?php else: ?>

                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>

                <td>
                <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($worker->section_id == $section->id): ?>
                        <input
                            style="border:none"
                            type="text"
                            id="section"
                            name="section"
                            value="<?php echo e($section->name); ?>"
                            placeholder="<?php echo e($section->name); ?>"
                            readonly>
                    <?php else: ?>

                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>

                <td><input style="border:none" type="text" name="speciality" value="<?php echo e($worker->speciality); ?>" placeholder="<?php echo e($worker->speciality); ?>" readonly></td>
                <td><input style="border:none" type="text" name="worker" value="<?php echo e($worker->name); ?> <?php echo e($worker->surname); ?>" placeholder="<?php echo e($worker->name); ?> <?php echo e($worker->surname); ?>" readonly></td>
                <td><input type="number" class="form-control" name="a" min="0" max="100" value="<?php echo e($a); ?>"></td>
                <td><input type="number" class="form-control" name="b" min="0" max="60" value="<?php echo e($b); ?>"></td>
                <td><input type="number" class="form-control" name="c" min="0" max="15" value="<?php echo e($c); ?>"></td>
                <td><input type="number" class="form-control" name="d" min="0" max="25" value="<?php echo e($d); ?>"></td>
                <td>
                    <button type="submit" class="btn btn-success" style="width: 150px"> Hisoblash </button>
                </td>

                <td>
                    <?php if(isset($all)): ?>
                    <p><?php echo e($all); ?>ball</p>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if(isset($percent)): ?>
                    <p><?php echo e($percent); ?>%</p>
                    <?php endif; ?>
                </td>
            </tr>
            </form>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    const message = document.querySelector('#alert')
    setTimeout(() => {
        message.style.display = 'none'
    }, 2000);
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\A_Project\Kpi.uz\resources\views/kpi/index.blade.php ENDPATH**/ ?>