@extends('layout.app')

@section('content')
    <h1>Xush Kelibsiz!</h1>
@endsection
